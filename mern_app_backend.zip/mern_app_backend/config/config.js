export const configType = {
  DB_URL:
    "mongodb+srv://Admin:mM4JZwmetebQpwCf@cluster0.obazy.mongodb.net/demoApp?retryWrites=true&w=majority",
  PORT: 5000,
};
