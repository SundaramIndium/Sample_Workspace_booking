import express from "express";
const router = express.Router();

import {
  signup,
  signin,
  getAllUsers,
  createUser,
  deleteUser,
} from "../controllers/user.js";

router.post("/signup", signup);
router.post("/signin", signin);
router.get("/getAllUsers", getAllUsers);
router.post("/createUser", createUser);
router.delete("/:id", deleteUser);

export default router;
