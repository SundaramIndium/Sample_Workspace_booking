import express from "express";
import mongoose from "mongoose";

const app = express();

export const openDb = async () => {
  return await mongoose
    .connect(
      "mongodb+srv://Admin:mM4JZwmetebQpwCf@cluster0.obazy.mongodb.net/demoApp?retryWrites=true&w=majority"
    )
    .then(() => console.log("Connected to Database"))
    .then(() => {
      app.listen(5000);
    })
    .catch((error) => console.log(error));
};
