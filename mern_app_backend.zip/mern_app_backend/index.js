import express from "express";
import mongoose from "mongoose";
import cors from "cors";
import morgan from "morgan";
import dotenv from "dotenv";
import userRouter from "./routes/user.js";

const app = express();
dotenv.config();

app.use(morgan("dev"));
app.use(express.json());
app.use(express.urlencoded());
app.use(cors());

app.use("/api/v1/users", userRouter);
// const port = process.env.PORT || 5000;

mongoose
  .connect(
    "mongodb+srv://Admin:mM4JZwmetebQpwCf@cluster0.obazy.mongodb.net/demoApp?retryWrites=true&w=majority"
  )
  .then(() => console.log("Connected to Database"))
  .then(() => {
    app.listen(5000);
  });
