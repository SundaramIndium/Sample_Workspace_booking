import express from "express";
import mongoose from "mongoose";
import cors from "cors";
import morgan from "morgan";
import dotenv from "dotenv";
import { configType } from "./config/config.js";
import userRouter from "./routes/user.js";
import { openDb } from "./db.js";

const app = express();
dotenv.config();

app.use(morgan("dev"));
app.use(express.json());
app.use(express.urlencoded());
app.use(cors());

app.use("/api/v1/users", userRouter);

// app.use((error, req, res, next) => {
//   console.log(error);
//   res.status(error.status || 500);
//   res.send({
//     error: {
//       status: error.status,
//       message: error.message,
//     },
//   });
// });

mongoose
  .connect(configType.DB_URL)
  .then(() => console.log("Connected to Database"))
  .then(() => {
    app.listen(configType.PORT);
  });

// openDb();
