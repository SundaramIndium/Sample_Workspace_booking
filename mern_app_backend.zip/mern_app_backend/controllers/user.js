import bcrypt from "bcryptjs";
import jwt from "jsonwebtoken";

import UserModal from "../models/user.js";
import { errorHandler } from "../service/customerror.js";

const secret = "test";

export const signin = async (req, res) => {
  const { email, password } = req.body;

  try {
    const oldUser = await UserModal.findOne({ email });
    if (!oldUser) {
      return res.status(404).json({ message: "User doesn't exist" });
    }

    const isPasswordCorrect = await bcrypt.compare(password, oldUser.password);

    if (!isPasswordCorrect) {
      return res.status(400).json({ message: "Invalid credentials" });
    }

    const token = jwt.sign({ email: oldUser.email, id: oldUser._id }, secret, {
      expiresIn: "1h",
    });

    res.status(200).json({ result: oldUser, token });
  } catch (error) {
    errorHandler(
      error,
      500,
      res,
      "Something error occured during server request"
    );
    // res.status(500).json({ message: "Something went wrong" });
    // console.log(error);
    // next(error);
  }
};

export const signup = async (req, res) => {
  const { email, password, company, name } = req.body;
  try {
    const oldUser = await UserModal.findOne({ email });

    if (oldUser) {
      return res.status(400).json({ message: "User already exists" });
    }

    const hashedPassword = await bcrypt.hash(password, 12);

    const result = await UserModal.create({
      email,
      password: hashedPassword,
      name,
      company,
    });

    const token = jwt.sign({ email: result.email, id: result._id }, secret, {
      expiresIn: "1h",
    });
    res.status(201).json({ result, token });
  } catch (error) {
    errorHandler(
      error,
      500,
      res,
      "Something error occured during server request"
    );
  }
};

export const getAllUsers = async (req, res, next) => {
  let users;

  try {
    users = await UserModal.find();
  } catch (error) {
    errorHandler(
      error,
      500,
      res,
      "Something error occured during server request"
    );
  }

  if (!users) {
    return res.status(404).json({ message: "No users found" });
  }
  return res.status(200).json({ users });
};

export const createUser = async (req, res) => {
  const { email, password, company, name } = req.body;
  try {
    const oldUser = await UserModal.findOne({ email });

    if (oldUser) {
      return res.status(400).json({ message: "User already exists" });
    }

    const hashedPassword = await bcrypt.hash(password, 12);

    const result = await UserModal.create({
      email,
      password: hashedPassword,
      name,
      company,
    });

    const token = jwt.sign({ email: result.email, id: result._id }, secret, {
      expiresIn: "1h",
    });
    res.status(201).json({ result, token });
  } catch (error) {
    errorHandler(
      error,
      500,
      res,
      "Something error occured during server request"
    );
  }
};

export const deleteUser = async (req, res) => {
  const id = req.params.id;
  let user;
  try {
    user = await UserModal.findByIdAndRemove(id);
  } catch (error) {
    errorHandler(
      error,
      500,
      res,
      "Something error occured during server request"
    );
  }
  if (!user) {
    return res.status(404).json({ message: "Unable to delete" });
  } else {
    return res.status(200).json({ user });
  }
};
