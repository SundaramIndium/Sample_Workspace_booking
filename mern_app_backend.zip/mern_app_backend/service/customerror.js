export const errorHandler = (err, statusCode, res, message) => {
  return res.status(statusCode).json({ msg: message });
};
